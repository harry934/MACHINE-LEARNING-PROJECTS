import time

# Writing directly to the disk every time, no buffering
def write_unbuffered(file_name, data):
    with open(file_name, "wb", buffering = 0) as f:
        for i in range(10000):
            f.write(data)

# Writing using the default buffer, faster than unbuffered
def write_buffered(file_name, data):
    with open(file_name, "wb") as f:
        for i in range(10000):
            f.write(data)

# Reading directly from disk without buffering
def read_uncached(file_name):
    with open(file_name, "rb", buffering=0) as f:
        while f.read(1024):
            pass

# Reading the whole file once into memory, then reuse it
def read_cached(file_name):
    with open(file_name, "rb") as f:
        cache = f.read()
    for i in range(5):
        content = cache

# Measuring how long each function takes
def measure(fn, label):
    start = time.time()
    fn()
    end = time.time()
    print(label, int((end - start) * 1000), "ms")

file = "testing.txt"
data = b"IST3020A\n"

# Running each test and printing the result
measure(lambda: write_unbuffered(file, data), "Unbuffered write:")
measure(lambda: write_buffered(file, data), "Buffered write:")
measure(lambda: read_uncached(file), "Uncached read:")
measure(lambda: read_cached(file), "Cached read:")
